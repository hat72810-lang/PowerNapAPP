/**
 * PowerNap Main Application Logic
 */

document.addEventListener('DOMContentLoaded', () => {
  // App State Variables
  let currentStep = 1;
  let audioMode = 'speaker'; // 'speaker' | 'earphone'
  let restDurationMinutes = 15; // default 15 min (or 20)
  
  let timerInterval = null;
  let remainingSeconds = 0;
  let totalRestSeconds = 0;
  
  let awakeInterval = null;
  let awakeRemainingSeconds = 0;
  let totalAwakeSeconds = 5 * 60; // 5 minutes = 300s

  let wakeLock = null;

  // DOM Elements
  const stepIndicatorEl = document.getElementById('step-indicator');
  const stepViews = {
    1: document.getElementById('step-1'),
    2: document.getElementById('step-2'),
    3: document.getElementById('step-3'),
    4: document.getElementById('step-4'),
    5: document.getElementById('step-5')
  };

  // Step 1 Controls
  const btnCoffeeConfirm = document.getElementById('btn-coffee-confirm');

  // Step 2 Controls
  const mudraContainerRest = document.getElementById('mudra-container-rest');
  const mudraNameRest = document.getElementById('mudra-name-rest');
  const mudraDescRest = document.getElementById('mudra-desc-rest');
  const btnModeSpeaker = document.getElementById('btn-mode-speaker');
  const btnModeEarphone = document.getElementById('btn-mode-earphone');
  const durationBtns = document.querySelectorAll('.duration-btn');
  const btnStartNap = document.getElementById('btn-start-nap');

  // Step 3 Controls
  const timerDigitsEl = document.getElementById('timer-digits');
  const timerProgressCircle = document.getElementById('timer-progress-circle');
  const audioModeBadgeText = document.getElementById('audio-mode-badge-text');
  const btnCancelNap = document.getElementById('btn-cancel-nap');

  // Step 4 Controls
  const mudraContainerAwake = document.getElementById('mudra-container-awake');
  const mudraNameAwake = document.getElementById('mudra-name-awake');
  const mudraDescAwake = document.getElementById('mudra-desc-awake');
  const awakeTimerDigits = document.getElementById('awake-timer-digits');
  const awakeProgressFill = document.getElementById('awake-progress-fill');
  const btnSkipAwake = document.getElementById('btn-skip-awake');

  // Step 5 Controls
  const btnResetApp = document.getElementById('btn-reset-app');

  // --- Initialize Mudra Content ---
  if (window.mudrasData) {
    mudraContainerRest.innerHTML = window.mudrasData.rest.svg;
    mudraNameRest.textContent = window.mudrasData.rest.name;
    mudraDescRest.textContent = window.mudrasData.rest.description;

    mudraContainerAwake.innerHTML = window.mudrasData.awake.svg;
    mudraNameAwake.textContent = window.mudrasData.awake.name;
    mudraDescAwake.textContent = window.mudrasData.awake.description;
  }

  // --- Screen Wake Lock Helper ---
  async function requestWakeLock() {
    if ('wakeLock' in navigator) {
      try {
        wakeLock = await navigator.wakeLock.request('screen');
      } catch (err) {
        console.warn('Wake Lock request failed:', err);
      }
    }
  }

  function releaseWakeLock() {
    if (wakeLock !== null) {
      wakeLock.release().catch(() => {});
      wakeLock = null;
    }
  }

  // --- Navigation & View Switching ---
  function goToStep(stepNumber) {
    currentStep = stepNumber;
    stepIndicatorEl.textContent = `STEP ${stepNumber} / 5`;

    Object.keys(stepViews).forEach(key => {
      if (parseInt(key) === stepNumber) {
        stepViews[key].classList.add('active');
      } else {
        stepViews[key].classList.remove('active');
      }
    });

    if (stepNumber === 3 || stepNumber === 4) {
      requestWakeLock();
    } else {
      releaseWakeLock();
    }
  }

  // --- Format Time Helper (MM:SS) ---
  function formatTime(seconds) {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }

  // --- Step 1 Event Listeners ---
  btnCoffeeConfirm.addEventListener('click', () => {
    goToStep(2);
  });

  // --- Step 2 Event Listeners (Mode & Duration Select) ---
  btnModeSpeaker.addEventListener('click', () => {
    audioMode = 'speaker';
    btnModeSpeaker.classList.add('active');
    btnModeEarphone.classList.remove('active');
  });

  btnModeEarphone.addEventListener('click', () => {
    audioMode = 'earphone';
    btnModeEarphone.classList.add('active');
    btnModeSpeaker.classList.remove('active');
  });

  let restDurationSeconds = 15 * 60; // default 15 min (or custom)

  durationBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      durationBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      const secAttr = btn.getAttribute('data-seconds');
      const minAttr = btn.getAttribute('data-minutes');
      if (secAttr) {
        restDurationSeconds = parseInt(secAttr, 10);
      } else if (minAttr) {
        restDurationSeconds = parseInt(minAttr, 10) * 60;
      }
    });
  });

  btnStartNap.addEventListener('click', () => {
    startPowerNapTimer();
  });

  // --- Step 3: Power Nap Timer Logic ---
  function startPowerNapTimer() {
    totalRestSeconds = restDurationSeconds;
    remainingSeconds = totalRestSeconds;
    
    // UI Updates
    timerDigitsEl.textContent = formatTime(remainingSeconds);
    audioModeBadgeText.textContent = audioMode === 'speaker' ? '528Hz + 4Hz 揺らぎ再生中' : '200/204Hz バイノーラル再生中';
    
    // Circle Stroke Init (Radius 90 => Circumference = 565.48)
    const circumference = 565.48;
    timerProgressCircle.style.strokeDasharray = `${circumference}`;
    timerProgressCircle.style.strokeDashoffset = `0`;

    // Audio Start
    if (window.powerNapAudio) {
      window.powerNapAudio.startRestSound(audioMode);
    }

    goToStep(3);

    // Countdown Interval
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = setInterval(() => {
      remainingSeconds--;
      
      timerDigitsEl.textContent = formatTime(remainingSeconds);
      
      // Update Circle Progress
      const progressFraction = (totalRestSeconds - remainingSeconds) / totalRestSeconds;
      const offset = circumference * progressFraction;
      timerProgressCircle.style.strokeDashoffset = `${offset}`;

      // 残り時間に応じたフェードアウト処理 (デフォルト15秒前、短い場合は残り半分の時点)
      const fadeTimeThreshold = Math.min(15, Math.floor(totalRestSeconds / 2));
      if (remainingSeconds === fadeTimeThreshold && window.powerNapAudio) {
        window.powerNapAudio.fadeRestSound(fadeTimeThreshold);
      }

      // タイマー終了
      if (remainingSeconds <= 0) {
        clearInterval(timerInterval);
        onNapTimerComplete();
      }
    }, 1000);
  }

  btnCancelNap.addEventListener('click', () => {
    if (timerInterval) clearInterval(timerInterval);
    if (window.powerNapAudio) window.powerNapAudio.stop();
    goToStep(2);
  });

  // --- Step 4: Awakening Phase Logic ---
  function onNapTimerComplete() {
    if (window.powerNapAudio) {
      window.powerNapAudio.playTransitionChime();
    }

    setTimeout(() => {
      startAwakeningPhase();
    }, 1500);
  }

  function startAwakeningPhase() {
    totalAwakeSeconds = 5 * 60; // 5分間
    awakeRemainingSeconds = totalAwakeSeconds;

    awakeTimerDigits.textContent = formatTime(awakeRemainingSeconds);
    awakeProgressFill.style.width = '0%';

    // 覚醒音スタート
    if (window.powerNapAudio) {
      window.powerNapAudio.startAwakeSound(audioMode);
    }

    goToStep(4);

    if (awakeInterval) clearInterval(awakeInterval);
    awakeInterval = setInterval(() => {
      awakeRemainingSeconds--;

      awakeTimerDigits.textContent = formatTime(awakeRemainingSeconds);

      // 進捗率 (0.0 -> 1.0)
      const progress = (totalAwakeSeconds - awakeRemainingSeconds) / totalAwakeSeconds;
      awakeProgressFill.style.width = `${progress * 100}%`;

      // 覚醒サウンドの音量・パルス周波数を進捗に合わせて更新
      if (window.powerNapAudio) {
        window.powerNapAudio.updateAwakeIntensity(progress);
      }

      // 5分間の覚醒フェーズ終了
      if (awakeRemainingSeconds <= 0) {
        clearInterval(awakeInterval);
        finishPowerNap();
      }
    }, 1000);
  }

  btnSkipAwake.addEventListener('click', () => {
    if (awakeInterval) clearInterval(awakeInterval);
    finishPowerNap();
  });

  // --- Step 5: Completion Screen Logic ---
  function finishPowerNap() {
    if (window.powerNapAudio) {
      window.powerNapAudio.stop();
    }
    goToStep(5);
  }

  btnResetApp.addEventListener('click', () => {
    if (timerInterval) clearInterval(timerInterval);
    if (awakeInterval) clearInterval(awakeInterval);
    if (window.powerNapAudio) window.powerNapAudio.stop();
    
    goToStep(1);
  });
});
