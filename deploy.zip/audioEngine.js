/**
 * PowerNap Web Audio Engine
 * 昼寝・覚醒のためのWeb Audio APIベースの音響合成エンジン
 */

class PowerNapAudioEngine {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.activeNodes = [];
    this.mode = 'speaker'; // 'speaker' | 'earphone'
    this.isPlaying = false;
    this.currentPhase = null; // 'rest' | 'awake'
    this.awakeLfo = null;
    this.awakeGain = null;
    this.awakeOsc1 = null;
    this.awakeOsc2 = null;
  }

  /**
   * AudioContextの初期化（iOS Safari対策：ユーザー操作時（タッチ等）に呼び出す）
   */
  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  /**
   * すべての再生中ノードを停止・クリーンアップ
   */
  stop() {
    this.activeNodes.forEach(node => {
      try {
        if (node.stop) node.stop();
        if (node.disconnect) node.disconnect();
      } catch (e) {
        // すでに停止している場合を回避
      }
    });
    this.activeNodes = [];
    this.awakeLfo = null;
    this.awakeGain = null;
    this.awakeOsc1 = null;
    this.awakeOsc2 = null;
    this.isPlaying = false;
    this.currentPhase = null;
  }

  /**
   * ステレオパンナーノードを作成（ブラウザ互換性対応）
   */
  createPanner(panValue) {
    if (this.ctx.createStereoPanner) {
      const panner = this.ctx.createStereoPanner();
      panner.pan.value = panValue;
      return panner;
    } else {
      // 古いSafariなどStereoPanner非対応環境用フォールバック
      const panner = this.ctx.createPanner();
      panner.panningModel = 'equalpower';
      panner.setPosition(panValue, 0, 1 - Math.abs(panValue));
      return panner;
    }
  }

  /**
   * 休息サウンド再生開始 (Step 3)
   * @param {string} mode 'speaker' | 'earphone'
   */
  startRestSound(mode = 'speaker') {
    this.init();
    this.stop();

    this.mode = mode;
    this.isPlaying = true;
    this.currentPhase = 'rest';

    const now = this.ctx.currentTime;
    
    // マスターゲイン
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(0.01, now);
    // 2秒かけてフェードイン
    this.masterGain.gain.exponentialRampToValueAtTime(0.35, now + 2);
    this.masterGain.connect(this.ctx.destination);

    if (mode === 'speaker') {
      // --- スピーカーモード ---
      // 528Hz 正弦波 (ソルフェジオ周波数) + 4Hz 揺らぎ (LFO Tremolo)
      
      // メインオシレーター (528Hz)
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(528, now);

      // Tremolo用のLFO (4Hz 揺らぎ)
      const lfo = this.ctx.createOscillator();
      lfo.type = 'sine';
      lfo.frequency.setValueAtTime(4, now); // 4Hzのゆらぎ

      const lfoGain = this.ctx.createGain();
      lfoGain.gain.setValueAtTime(0.18, now); // 揺らぎの深さ

      const carrierGain = this.ctx.createGain();
      carrierGain.gain.setValueAtTime(0.4, now);

      // LFO -> carrierGain.gain
      lfo.connect(lfoGain);
      lfoGain.connect(carrierGain.gain);

      // 補助サブオシレーター (132Hz / 264Hz 柔らかなハーモニクス)
      const subOsc = this.ctx.createOscillator();
      subOsc.type = 'sine';
      subOsc.frequency.setValueAtTime(264, now);
      const subGain = this.ctx.createGain();
      subGain.gain.setValueAtTime(0.08, now);

      osc.connect(carrierGain);
      subOsc.connect(subGain);

      carrierGain.connect(this.masterGain);
      subGain.connect(this.masterGain);

      osc.start(now);
      lfo.start(now);
      subOsc.start(now);

      this.activeNodes.push(osc, lfo, lfoGain, carrierGain, subOsc, subGain);

    } else {
      // --- イヤホンモード (バイノーラルビート) ---
      // 左耳: 200Hz, 右耳: 204Hz (差分 4Hz シータ波)

      // 左耳チャンネル
      const oscLeft = this.ctx.createOscillator();
      oscLeft.type = 'sine';
      oscLeft.frequency.setValueAtTime(200, now);

      const pannerLeft = this.createPanner(-1.0); // 完全左パン
      const gainLeft = this.ctx.createGain();
      gainLeft.gain.setValueAtTime(0.3, now);

      oscLeft.connect(gainLeft);
      gainLeft.connect(pannerLeft);
      pannerLeft.connect(this.masterGain);

      // 右耳チャンネル
      const oscRight = this.ctx.createOscillator();
      oscRight.type = 'sine';
      oscRight.frequency.setValueAtTime(204, now);

      const pannerRight = this.createPanner(1.0); // 完全右パン
      const gainRight = this.ctx.createGain();
      gainRight.gain.setValueAtTime(0.3, now);

      oscRight.connect(gainRight);
      gainRight.connect(pannerRight);
      pannerRight.connect(this.masterGain);

      oscLeft.start(now);
      oscRight.start(now);

      this.activeNodes.push(oscLeft, pannerLeft, gainLeft, oscRight, pannerRight, gainRight);
    }
  }

  /**
   * 休息タイマー終了直前のサウンドフェードアウト
   * @param {number} durationSeconds フェードアウトにかける秒数 (例: 15秒)
   */
  fadeRestSound(durationSeconds = 15) {
    if (!this.masterGain || !this.ctx) return;
    const now = this.ctx.currentTime;
    this.masterGain.gain.cancelScheduledValues(now);
    this.masterGain.gain.setValueAtTime(this.masterGain.gain.value || 0.35, now);
    this.masterGain.gain.linearRampToValueAtTime(0.0001, now + durationSeconds);
  }

  /**
   * 覚醒フェーズへの遷移チャイム音の再生
   */
  playTransitionChime() {
    this.init();
    const now = this.ctx.currentTime;
    
    // 心地よい透明感のある和音チャイム (528Hz, 660Hz, 792Hz, 1056Hz)
    const freqs = [528, 660, 792, 1056];
    freqs.forEach((freq, idx) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.15);

      gain.gain.setValueAtTime(0.001, now + idx * 0.15);
      gain.gain.exponentialRampToValueAtTime(0.2, now + idx * 0.15 + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.15 + 2.5);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now + idx * 0.15);
      osc.stop(now + idx * 0.15 + 2.6);
    });
  }

  /**
   * 覚醒サウンド再生開始 (Step 4 - 5分間)
   * @param {string} mode 'speaker' | 'earphone'
   */
  startAwakeSound(mode = 'speaker') {
    this.init();
    this.stop();

    this.mode = mode;
    this.isPlaying = true;
    this.currentPhase = 'awake';

    const now = this.ctx.currentTime;

    this.masterGain = this.ctx.createGain();
    // 覚醒の初期音量は控えめからスタート
    this.masterGain.gain.setValueAtTime(0.05, now);
    this.masterGain.connect(this.ctx.destination);

    if (mode === 'speaker') {
      // --- スピーカーモード ---
      // 432Hz ベース + 40Hz アイソクロニックトーン (40Hzの高速パルス)
      
      const osc = this.ctx.createOscillator();
      osc.type = 'triangle'; // 三角波で適度な倍音とシャープさを確保
      osc.frequency.setValueAtTime(432, now);
      this.awakeOsc1 = osc;

      // アイソクロニック・パルス用のLFO (初期40Hz)
      const lfo = this.ctx.createOscillator();
      lfo.type = 'square'; // クッキリしたパルス音
      lfo.frequency.setValueAtTime(40, now);
      this.awakeLfo = lfo;

      const lfoGain = this.ctx.createGain();
      lfoGain.gain.setValueAtTime(0.4, now); // パルスの強さ

      const pulseGain = this.ctx.createGain();
      pulseGain.gain.setValueAtTime(0.4, now);
      this.awakeGain = pulseGain;

      lfo.connect(lfoGain);
      lfoGain.connect(pulseGain.gain);

      osc.connect(pulseGain);
      pulseGain.connect(this.masterGain);

      osc.start(now);
      lfo.start(now);

      this.activeNodes.push(osc, lfo, lfoGain, pulseGain);

    } else {
      // --- イヤホンモード ---
      // 左耳: 200Hz, 右耳: 240Hz (差分 40Hz ガンマ波バイノーラルビート)

      const oscLeft = this.ctx.createOscillator();
      oscLeft.type = 'sine';
      oscLeft.frequency.setValueAtTime(200, now);
      this.awakeOsc1 = oscLeft;

      const pannerLeft = this.createPanner(-1.0);
      const gainLeft = this.ctx.createGain();
      gainLeft.gain.setValueAtTime(0.3, now);

      oscLeft.connect(gainLeft);
      gainLeft.connect(pannerLeft);
      pannerLeft.connect(this.masterGain);

      const oscRight = this.ctx.createOscillator();
      oscRight.type = 'sine';
      oscRight.frequency.setValueAtTime(240, now);
      this.awakeOsc2 = oscRight;

      const pannerRight = this.createPanner(1.0);
      const gainRight = this.ctx.createGain();
      gainRight.gain.setValueAtTime(0.3, now);

      oscRight.connect(gainRight);
      gainRight.connect(pannerRight);
      pannerRight.connect(this.masterGain);

      oscLeft.start(now);
      oscRight.start(now);

      this.activeNodes.push(oscLeft, pannerLeft, gainLeft, oscRight, pannerRight, gainRight);
    }
  }

  /**
   * 覚醒5分間の進捗（0.0 ~ 1.0）に応じて音量とテンポ/パルス感を漸増させる
   * @param {number} progress 0.0 ~ 1.0
   */
  updateAwakeIntensity(progress) {
    if (!this.isPlaying || this.currentPhase !== 'awake' || !this.ctx || !this.masterGain) return;
    
    const now = this.ctx.currentTime;
    const clampedProgress = Math.max(0, Math.min(1, progress));

    // 音量を0.05から0.55へ徐々にアップ
    const targetVolume = 0.05 + clampedProgress * 0.50;
    this.masterGain.gain.setValueAtTime(targetVolume, now);

    // スピーカーモードの場合、40Hz〜45Hzへパルス速度を微増 & 周波数を上げる
    if (this.mode === 'speaker' && this.awakeLfo && this.awakeOsc1) {
      const pulseFreq = 40 + clampedProgress * 5; // 40Hz -> 45Hz
      const baseFreq = 432 + clampedProgress * 20; // 432Hz -> 452Hz
      this.awakeLfo.frequency.setValueAtTime(pulseFreq, now);
      this.awakeOsc1.frequency.setValueAtTime(baseFreq, now);
    } 
    // イヤホンモードの場合、覚醒に従ってピッチを若干明るくシフト
    else if (this.mode === 'earphone' && this.awakeOsc1 && this.awakeOsc2) {
      const leftFreq = 200 + clampedProgress * 20; // 200Hz -> 220Hz
      const rightFreq = 240 + clampedProgress * 20; // 240Hz -> 260Hz
      this.awakeOsc1.frequency.setValueAtTime(leftFreq, now);
      this.awakeOsc2.frequency.setValueAtTime(rightFreq, now);
    }
  }
}

// シングルトンインスタンスをグローバル提供
window.powerNapAudio = new PowerNapAudioEngine();
