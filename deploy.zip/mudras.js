/**
 * Mudra Data & SVG Graphics Definitions
 */

const mudrasData = {
  rest: {
    id: 'chin_mudra',
    name: 'チン・ムドラー (Chin Mudra)',
    subtitle: '深い静寂とリラックスに導く印',
    description: '親指と人差し指の先端を優しく合わせ、輪を作ります。残りの3本の指は自然に伸ばして掌を上に向け、膝の上に置きます。副交感神経を優位にし、心を沈静化させます。',
    benefits: ['副交感神経の活性化', '脳波（α波/θ波）の安定', '雑念の抑制'],
    svg: `
      <svg viewBox="0 0 200 200" class="mudra-svg" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <radialGradient id="glowRest" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="#7c4dff" stop-opacity="0.6"/>
            <stop offset="100%" stop-color="#7c4dff" stop-opacity="0"/>
          </radialGradient>
          <linearGradient id="handGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#a78bfa"/>
            <stop offset="100%" stop-color="#6d28d9"/>
          </linearGradient>
        </defs>

        <!-- 背景の輝き -->
        <circle cx="100" cy="100" r="85" fill="url(#glowRest)" />

        <!-- ガイド円 (親指と人差し指のタッチポイント) -->
        <circle cx="95" cy="85" r="30" stroke="#00e5ff" stroke-width="1.5" stroke-dasharray="4,4" fill="none" class="pulse-ring" />
        
        <!-- 手のグラフィック (アラインライン & シルエット) -->
        <g stroke="url(#handGrad)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" fill="none">
          <!-- 手首と手の甲 -->
          <path d="M 40,165 Q 60,130 75,120 T 110,120" />
          
          <!-- 親指 (曲げて円をつくる) -->
          <path d="M 65,130 C 60,105 75,80 90,85" stroke="#00e5ff" stroke-width="5" />
          
          <!-- 人差し指 (親指と接触) -->
          <path d="M 105,120 C 120,95 105,80 98,85" stroke="#00e5ff" stroke-width="5" />
          
          <!-- 中指 (直伸) -->
          <path d="M 115,120 Q 140,105 160,100" />
          
          <!-- 薬指 (直伸) -->
          <path d="M 112,128 Q 138,118 158,115" />
          
          <!-- 小指 (直伸) -->
          <path d="M 108,136 Q 132,130 150,130" />

          <!-- 接点のエナジーポイント -->
          <circle cx="94" cy="85" r="6" fill="#00e5ff" stroke="#ffffff" stroke-width="2" class="energy-node" />
        </g>
      </svg>
    `
  },
  awake: {
    id: 'surya_mudra',
    name: 'スーリヤ・ムドラー (Surya Mudra)',
    subtitle: '交感神経を刺激し、頭脳を鮮明にする印',
    description: '薬指を折って親指の付け根につけ、親指で薬指の第二関節を上から優しく押さえます。他の3本の指はまっすぐ伸ばします。体熱を上昇させ、代謝と交感神経を刺激してスッキリ覚醒させます。',
    benefits: ['交感神経のONスイッチ', '体温・代謝のアップ', '頭脳の明晰化'],
    svg: `
      <svg viewBox="0 0 200 200" class="mudra-svg" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <radialGradient id="glowAwake" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="#ff6e40" stop-opacity="0.6"/>
            <stop offset="100%" stop-color="#ff6e40" stop-opacity="0"/>
          </radialGradient>
          <linearGradient id="awakeHandGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#ffab40"/>
            <stop offset="100%" stop-color="#ff3d00"/>
          </linearGradient>
        </defs>

        <!-- 背景の太陽フレアの輝き -->
        <circle cx="100" cy="100" r="85" fill="url(#glowAwake)" />
        
        <!-- 太陽エネルギーのリング -->
        <circle cx="100" cy="100" r="70" stroke="#ffab40" stroke-width="1.5" stroke-dasharray="6,6" fill="none" class="sun-ring" />

        <!-- 手のグラフィック -->
        <g stroke="url(#awakeHandGrad)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" fill="none">
          <!-- 手首 -->
          <path d="M 40,165 Q 60,135 80,125" />
          
          <!-- 人差し指 (上向きに直伸) -->
          <path d="M 90,120 Q 100,70 105,45" stroke="#ffea00" stroke-width="4.5" />
          
          <!-- 中指 (上向きに直伸) -->
          <path d="M 102,120 Q 120,65 125,40" stroke="#ffea00" stroke-width="4.5" />

          <!-- 薬指 (折り曲げる) -->
          <path d="M 112,122 C 120,110 100,90 90,105" stroke="#ff6e40" stroke-width="5" />

          <!-- 親指 (薬指を押さえる) -->
          <path d="M 70,130 C 65,105 85,95 95,100" stroke="#ffab40" stroke-width="5" />

          <!-- 小指 (直伸) -->
          <path d="M 120,126 Q 145,85 150,60" stroke="#ffea00" stroke-width="4.5" />

          <!-- 交感神経刺激ノード -->
          <circle cx="92" cy="102" r="7" fill="#ffea00" stroke="#ffffff" stroke-width="2" class="energy-node-fire" />
        </g>
      </svg>
    `
  }
};
